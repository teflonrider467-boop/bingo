import React from 'react'

const CorporateBooking = () => {
  return (
    <div>CorporateBooking</div>
  )
}

export default CorporateBooking