import React from 'react'

const TourAndPackage = () => {
  return (
    <div>TourAndPackage</div>
  )
}

export default TourAndPackage